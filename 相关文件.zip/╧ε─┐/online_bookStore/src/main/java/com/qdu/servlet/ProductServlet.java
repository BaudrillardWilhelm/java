package com.qdu.servlet;

public interface ProductServlet {
}
